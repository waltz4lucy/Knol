#Sublime-Finder
Sublime Text 2 plugin for opening finder in the current directory
When installed, provides the "Finder: Open here" command, which opens finder in the current file's folder in Finder, much like [The Sublime Terminal plugin](http://wbond.net/sublime_packages/terminal)

##Installation
1. Download [the zip file](https://github.com/kallepersson/Sublime-Finder/zipball/master)
2. unzip it and rename it to "Sublime-Finder" or something
3. Move it to ~/Library/Application Support/Sublime Text 2/Packages/